# Sources For Graphics

* [bardo.png](https://finalbossblues.com/timefantasy/freebies/bard-character-with-animations)
* [darkdimension.png](https://finalbossblues.com/timefantasy/freebies/dark-dimension-tileset)
* [reaper.png](https://finalbossblues.com/timefantasy/freebies/grim-reaper-sprites)

[License](https://finalbossblues.com/timefantasy/free-graphics)